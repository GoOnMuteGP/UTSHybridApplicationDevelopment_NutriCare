import React, { useState } from "react";
import {
    View,
    Text,
    Image,
    TextInput,
    Pressable,
    StatusBar,
    ScrollView,
    StyleSheet,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const colors = {
    primary: "#33664b",
    secondary: "#58605c",
    surface: "#f5fbf4",
    "on-surface": "#171d19",
    "surface-container": "#eaefe9",
    "surface-container-low": "#eff5ef",
    "surface-container-high": "#e4eae3",
    "surface-container-lowest": "#ffffff",
    "on-primary": "#ffffff",
};

const spacing = {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
};

const borderRadius = {
    lg: 8,
    xl: 12,
    full: 9999,
};

const fontSize = {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 24,
};

export default function LoginScreen() {
    const [currentMode, setCurrentMode] = useState("login");
    const [showPassword, setShowPassword] = useState(false);
    const [fullName, setFullName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const isSignup = currentMode === "signup";

    return (
        <ScrollView
            style={styles.container}
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
        >
            <View style={styles.header}>
                <View style={styles.logoContainer}>
                    <Image
                        source={{
                            uri: "https://lh3.googleusercontent.com/aida/AEtjO1VBOSG0POEuL4gWWuod4XW-5ZDVchUw_CmCPETipkdr7G0p5xL0vJXdZXK_RANktykztI15hj0pc5PxS1J1gQjAI-UbFzSt4PcElFjxbuc5d0TD0W6dQNZSjFpig4SQ0xdgTpt7ZLCBbFMbtRyXKd-h5eb6DTdZWugX8Cao0UpbXhlSJeAREy-fHYK1moLyFM0iaBrAKprytbCdYN2S5vdG22KsYZemdGvJ0WnhJA5ffQ",
                        }}
                        style={styles.logo}
                        resizeMode="contain"
                    />
                </View>

                <Text style={styles.appName}>NutriCare</Text>

                <Text style={styles.subtitle}>
                    Simple, balanced daily nutrition
                </Text>
            </View>

            <View style={styles.tabContainer}>
                <Pressable
                    onPress={() => setCurrentMode("login")}
                    style={[
                        styles.tab,
                        !isSignup && styles.activeTab,
                    ]}
                >
                    <Text
                        style={[
                            styles.tabText,
                            !isSignup && styles.activeTabText,
                        ]}
                    >
                        Log In
                    </Text>
                </Pressable>

                <Pressable
                    onPress={() => setCurrentMode("signup")}
                    style={[
                        styles.tab,
                        isSignup && styles.activeTab,
                    ]}
                >
                    <Text
                        style={[
                            styles.tabText,
                            isSignup && styles.activeTabText,
                        ]}
                    >
                        Sign Up
                    </Text>
                </Pressable>
            </View>

            <View style={styles.form}>
                {isSignup && (
                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Full Name</Text>

                        <TextInput
                            value={fullName}
                            onChangeText={setFullName}
                            placeholder="Alex Rivera"
                            placeholderTextColor={colors.secondary}
                            style={styles.input}
                        />
                    </View>
                )}

                <View style={styles.inputGroup}>
                    <Text style={styles.label}>
                        University or Personal Email
                    </Text>

                    <TextInput
                        value={email}
                        onChangeText={setEmail}
                        placeholder="alex@university.edu"
                        placeholderTextColor={colors.secondary}
                        keyboardType="email-address"
                        autoCapitalize="none"
                        style={styles.input}
                    />
                </View>

                <View style={styles.inputGroup}>
                    <View style={styles.passwordHeader}>
                        <Text style={styles.label}>Password</Text>

                        {!isSignup && (
                            <Pressable>
                                <Text style={styles.forgotText}>
                                    Forgot?
                                </Text>
                            </Pressable>
                        )}
                    </View>

                    <View style={styles.passwordContainer}>
                        <TextInput
                            value={password}
                            onChangeText={setPassword}
                            placeholder="••••••••••••"
                            placeholderTextColor={colors.secondary}
                            secureTextEntry={!showPassword}
                            style={styles.passwordInput}
                        />

                        <Pressable
                            onPress={() => setShowPassword(!showPassword)}
                        >
                            <Text style={styles.showPassword}>
                                {showPassword ? "Hide" : "Show"}
                            </Text>
                        </Pressable>
                    </View>
                </View>

                <View style={styles.verification}>
                    <Text style={styles.checkmark}>✓</Text>

                    <Text style={styles.verificationText}>
                        Verified for eligible campus meal & nutrition plans
                    </Text>
                </View>

                <Pressable style={styles.submitButton}>
                    <Text style={styles.submitText}>
                        {isSignup ? "Create Account  →" : "Log In  →"}
                    </Text>
                </Pressable>
            </View>

            <View style={styles.dividerContainer}>
                <View style={styles.divider} />

                <Text style={styles.dividerText}>
                    or continue with
                </Text>

                <View style={styles.divider} />
            </View>

            <View style={styles.socialContainer}>
                <Pressable style={styles.socialButton}>
                    <Text style={styles.socialText}>
                        G  Google
                    </Text>
                </Pressable>

                <Pressable style={styles.socialButton}>
                    <Text style={styles.socialText}>
                        Apple
                    </Text>
                </Pressable>
            </View>

            <Text style={styles.terms}>
                By continuing, you agree to NutriCare's{" "}
                <Text style={styles.termsLink}>
                    Terms of Service
                </Text>
                {" "}and{" "}
                <Text style={styles.termsLink}>
                    Privacy Policy
                </Text>
                .
            </Text>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.surface,
    },
    content: {
        width: "100%",
        maxWidth: 448,
        alignSelf: "center",
        paddingHorizontal: spacing.md,
        paddingBottom: spacing.xl,
    },
    header: {
        alignItems: "center",
        paddingTop: spacing.xl,
        paddingBottom: spacing.sm,
    },
    logoContainer: {
        width: 64,
        height: 64,
        borderRadius: 16,
        backgroundColor: colors["surface-container"],
        alignItems: "center",
        justifyContent: "center",
        marginBottom: spacing.sm,
    },
    logo: {
        width: 40,
        height: 40,
    },
    appName: {
        fontSize: fontSize.lg,
        fontWeight: "600",
        color: colors["on-surface"],
    },
    subtitle: {
        fontSize: fontSize.sm,
        color: colors.secondary,
        marginTop: spacing.xs,
    },
    tabContainer: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors["surface-container"],
        padding: 4,
        borderRadius: borderRadius.xl,
        marginTop: spacing.lg,
        marginBottom: spacing.lg,
    },
    tab: {
        flex: 1,
        paddingVertical: 12,
        borderRadius: borderRadius.lg,
        alignItems: "center",
    },
    activeTab: {
        backgroundColor: colors["surface-container-lowest"],
    },
    tabText: {
        fontSize: fontSize.sm,
        color: colors.secondary,
    },
    activeTabText: {
        color: colors["on-surface"],
        fontWeight: "600",
    },
    form: {
        backgroundColor: colors["surface-container-lowest"],
        borderRadius: borderRadius.xl,
        padding: 20,
        gap: spacing.md,
    },
    inputGroup: {
        gap: spacing.sm,
    },
    label: {
        fontSize: fontSize.sm,
        fontWeight: "500",
        color: colors["on-surface"],
    },
    input: {
        width: "100%",
        height: 48,
        paddingHorizontal: spacing.md,
        borderRadius: borderRadius.xl,
        backgroundColor: colors["surface-container-low"],
        color: colors["on-surface"],
        fontSize: fontSize.sm,
    },
    passwordHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    forgotText: {
        fontSize: fontSize.xs,
        color: colors.primary,
    },
    passwordContainer: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors["surface-container-low"],
        borderRadius: borderRadius.xl,
        paddingRight: spacing.md,
    },
    passwordInput: {
        flex: 1,
        height: 48,
        paddingHorizontal: spacing.md,
        color: colors["on-surface"],
        fontSize: fontSize.sm,
    },
    showPassword: {
        color: colors.secondary,
        fontSize: fontSize.sm,
    },
    verification: {
        flexDirection: "row",
        alignItems: "center",
        gap: spacing.sm,
        padding: 12,
        borderRadius: borderRadius.lg,
        backgroundColor: colors["surface-container-low"],
    },
    checkmark: {
        color: colors.primary,
        fontSize: fontSize.md,
    },
    verificationText: {
        flex: 1,
        color: colors.secondary,
        fontSize: fontSize.xs,
    },
    submitButton: {
        width: "100%",
        height: 48,
        borderRadius: borderRadius.xl,
        backgroundColor: colors.primary,
        alignItems: "center",
        justifyContent: "center",
        marginTop: spacing.sm,
    },
    submitText: {
        color: colors["on-primary"],
        fontSize: fontSize.sm,
        fontWeight: "600",
    },
    dividerContainer: {
        flexDirection: "row",
        alignItems: "center",
        paddingVertical: spacing.sm,
        marginTop: spacing.md,
    },
    divider: {
        flex: 1,
        height: 1,
        backgroundColor: colors["surface-container-high"],
    },
    dividerText: {
        marginHorizontal: spacing.md,
        fontSize: fontSize.xs,
        color: colors.secondary,
        textTransform: "uppercase",
    },
    socialContainer: {
        flexDirection: "row",
        gap: 12,
    },
    socialButton: {
        flex: 1,
        height: 48,
        borderRadius: borderRadius.xl,
        backgroundColor: colors["surface-container-lowest"],
        alignItems: "center",
        justifyContent: "center",
    },
    socialText: {
        color: colors["on-surface"],
        fontSize: fontSize.sm,
        fontWeight: "500",
    },
    terms: {
        fontSize: fontSize.xs,
        color: colors.secondary,
        textAlign: "center",
        paddingHorizontal: spacing.md,
        lineHeight: 20,
        marginTop: spacing.lg,
    },
    termsLink: {
        color: colors["on-surface"],
        textDecorationLine: "underline",
    },
});