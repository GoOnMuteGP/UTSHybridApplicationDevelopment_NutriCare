import React from "react";
import {
    View,
    Text,
    Image,
    TextInput,
    Pressable,
    StatusBar,
    ScrollView,
    StyleSheet,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

const colors = {
    "primary-fixed": "#b7efcc",
    "on-surface": "#171d19",
    "on-tertiary-fixed-variant": "#8b191d",
    secondary: "#58605c",
    "surface-container": "#eaefe9",
    "secondary-fixed": "#dce4df",
    "surface-container-highest": "#dee4de",
    "on-background": "#171d19",
    "inverse-on-surface": "#ecf2ec",
    "on-error": "#ffffff",
    "on-surface-variant": "#414943",
    "on-tertiary-fixed": "#410004",
    outline: "#717972",
    "surface-container-lowest": "#ffffff",
    "on-primary-container": "#f6fff6",
    "tertiary-fixed": "#ffdad7",
    "on-primary-fixed-variant": "#1b5036",
    "surface-tint": "#35684d",
    "on-tertiary-container": "#fffbff",
    "on-error-container": "#93000a",
    "surface-bright": "#f5fbf4",
    "inverse-surface": "#2c322e",
    "surface-dim": "#d6dcd5",
    "primary-container": "#4c7f62",
    primary: "#33664b",
    "secondary-container": "#dae2dc",
    error: "#ba1a1a",
    "on-secondary-container": "#5c6460",
    "surface-container-high": "#e4eae3",
    "tertiary-fixed-dim": "#ffb3ae",
    "on-secondary-fixed": "#161d1a",
    tertiary: "#a8302f",
    "secondary-fixed-dim": "#c0c8c3",
    "outline-variant": "#c0c9c1",
    "inverse-primary": "#9cd3b1",
    surface: "#f5fbf4",
    "on-tertiary": "#ffffff",
    "on-secondary-fixed-variant": "#414944",
    "surface-variant": "#dee4de",
    background: "#f5fbf4",
    "tertiary-container": "#ca4845",
    "error-container": "#ffdad6",
    "on-primary-fixed": "#002112",
    "primary-fixed-dim": "#9cd3b1",
    "on-secondary": "#ffffff",
    "on-primary": "#ffffff",
    "surface-container-low": "#eff5ef",
};

const spacing = {
    margin: 16,
    gutter: 16,
    "space-xs": 4,
    "margin-tablet": 24,
    "space-xl": 32,
    "space-sm": 8,
    "gutter-sm": 12,
    "margin-mobile": 16,
    "space-md": 16,
    "space-lg": 24,
};

const borderRadius = {
    default: 4,
    lg: 8,
    xl: 12,
    full: 9999,
};

const fontSize = {
    "label-sm": 11,
    "label-md": 13,
    "display-lg": 32,
    "data-metric": 22,
    "body-sm": 13,
    "headline-sm": 17,
    "body-lg": 16,
    "body-md": 14,
    "headline-md": 20,
    "label-lg": 15,
    "headline-lg": 26,
};

const fontFamily = {
    default: "Inter",
};

export default function Home() {
    return (
        <SafeAreaView style={styles.safeArea}>
            <StatusBar barStyle="dark-content"
            />

            <ScrollView
                style={styles.container}
                contentContainerStyle={styles.content}
                showsVerticalScrollIndicator={false}
            >
                <Text style={styles.title}>
                    React Native Application
                </Text>

                <Text style={styles.description}>
                    Theme configuration successfully converted.
                </Text>

                <View style={styles.primaryBox}>
                    <Text style={styles.primaryText}>
                        Primary Color
                    </Text>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        backgroundColor: colors.background,
    },
    container: {
        flex: 1,
    },
    content: {
        padding: spacing.margin,
    },
    title: {
        fontSize: fontSize["headline-lg"],
        fontWeight: "600",
        color: colors["on-surface"],
        fontFamily: fontFamily.default,
    },
    description: {
        fontSize: fontSize["body-md"],
        color: colors["on-surface-variant"],
        marginTop: spacing["space-sm"],
        fontFamily: fontFamily.default,
    },
    primaryBox: {
        backgroundColor: colors.primary,
        padding: spacing["space-lg"],
        borderRadius: borderRadius.lg,
        marginTop: spacing["space-xl"],
    },
    primaryText: {
        fontSize: fontSize["label-lg"],
        fontWeight: "600",
        color: colors["on-primary"],
        fontFamily: fontFamily.default,
    },
});